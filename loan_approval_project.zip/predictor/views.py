import os
import pandas as pd
import numpy as np
import joblib
from django.shortcuts import render
from django.core.files.storage import FileSystemStorage

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, 'ml_models')

def load_artifacts():
    try:
        model = joblib.load(os.path.join(MODEL_DIR, 'loan_model.pkl'))
        scaler = joblib.load(os.path.join(MODEL_DIR, 'scaler.pkl'))
        feature_cols = joblib.load(os.path.join(MODEL_DIR, 'feature_columns.pkl'))
        encoders = joblib.load(os.path.join(MODEL_DIR, 'label_encoders.pkl'))
        target_encoder = joblib.load(os.path.join(MODEL_DIR, 'target_encoder.pkl'))
        return model, scaler, feature_cols, encoders, target_encoder
    except Exception:
        return None, None, None, None, None

def upload_view(request):
    context = {}
    if request.method == 'POST' and request.FILES.get('dataset'):
        uploaded_file = request.FILES['dataset']
        fs = FileSystemStorage()
        filename = fs.save(uploaded_file.name, uploaded_file)
        filepath = fs.path(filename)
        
        try:
            if filename.endswith('.csv'):
                df = pd.read_csv(filepath)
            else:
                df = pd.read_excel(filepath)
                
            context['filename'] = uploaded_file.name
            context['rows'] = df.shape[0]
            context['columns'] = df.shape[1]
            context['missing_summary'] = df.isnull().sum().to_dict()
            context['preview_table'] = df.head(10).to_html(classes='table table-striped table-hover mt-3', index=False)
            context['numeric_cols'] = list(df.select_dtypes(include=[np.number]).columns)
            context['cat_cols'] = list(df.select_dtypes(include=['object']).columns)
        except Exception as e:
            context['error'] = f"Failed to process file: {str(e)}"
            
    return render(request, 'predictor/upload.html', context)

def predict_view(request):
    model, scaler, feature_cols, encoders, target_encoder = load_artifacts()
    context = {}
    
    if not model:
        context['error'] = "Model artifacts not found! Please run 'python pipeline.py' first."
        return render(request, 'predictor/predict.html', context)
        
    if request.method == 'POST':
        try:
            input_dict = {}
            for col in feature_cols:
                val = request.POST.get(col)
                if col in encoders:
                    input_dict[col] = encoders[col].transform([val])[0]
                else:
                    input_dict[col] = float(val) if val else 0.0
                    
            input_df = pd.DataFrame([input_dict])[feature_cols]
            scaled_input = scaler.transform(input_df)
            pred = model.predict(scaled_input)[0]
            
            result_text = target_encoder.inverse_transform([pred])[0] if target_encoder else str(pred)
            context['prediction'] = result_text
            context['input_values'] = request.POST
        except Exception as e:
            context['error'] = f"Error during prediction: {str(e)}"
            
    return render(request, 'predictor/predict.html', context)
