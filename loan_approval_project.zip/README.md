# Data Mining Mini-Project: Loan Approval Predictor

This project contains two core modules:
1. **Part 1 (Backend Pipeline):** `pipeline.py` cleans raw Kaggle dataset, treats missing values and outliers, performs feature scaling, trains a Random Forest Classifier, and exports model artifacts.
2. **Part 2 (Django Web App):** Web application enabling raw dataset file upload (.csv/.xlsx), automated dataset summary/preview, and interactive real-time predictions.

## Quickstart Instructions

1. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run Pipeline (Train & Generate Model Artifacts):**
   ```bash
   python pipeline.py
   ```

3. **Run Django Migrations:**
   ```bash
   python manage.py migrate
   ```

4. **Start Web Server:**
   ```bash
   python manage.py runserver
   ```

5. **Access Application:**
   Open `http://127.0.0.1:8000/` in your browser.
   - Upload the included `sample_loan_data.csv` on the home page.
   - Use the **Predict** tab for interactive inputs.
