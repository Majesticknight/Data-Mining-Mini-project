import pandas as pd
import numpy as np
import joblib
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

def create_sample_dataset():
    np.random.seed(42)
    n_samples = 600
    data = {
        'loan_id': [f'LP{i:04d}' for i in range(1, n_samples + 1)],
        'no_of_dependents': np.random.randint(0, 5, n_samples),
        'education': np.random.choice(['Graduate', 'Not Graduate'], n_samples),
        'self_employed': np.random.choice(['Yes', 'No'], n_samples),
        'income_annum': np.random.randint(200000, 9900000, n_samples),
        'loan_amount': np.random.randint(300000, 35000000, n_samples),
        'loan_term': np.random.choice([2, 4, 6, 8, 10, 12, 14, 16, 18, 20], n_samples),
        'cibil_score': np.random.randint(300, 900, n_samples),
        'residential_assets_value': np.random.randint(0, 25000000, n_samples),
        'commercial_assets_value': np.random.randint(0, 15000000, n_samples),
        'luxury_assets_value': np.random.randint(0, 25000000, n_samples),
        'bank_asset_value': np.random.randint(0, 10000000, n_samples),
        'loan_status': np.random.choice(['Approved', 'Rejected'], n_samples, p=[0.6, 0.4])
    }
    df = pd.DataFrame(data)
    # Introduce some missing values for realistic imputation demonstration
    df.loc[df.sample(frac=0.05).index, 'income_annum'] = np.nan
    df.loc[df.sample(frac=0.03).index, 'self_employed'] = np.nan
    
    df.to_csv('sample_loan_data.csv', index=False)
    print("Sample dataset 'sample_loan_data.csv' created.")
    return df

def run_pipeline():
    print("--- Running Data Mining & ML Pipeline ---")
    if not os.path.exists('sample_loan_data.csv'):
        df = create_sample_dataset()
    else:
        df = pd.read_csv('sample_loan_data.csv')

    # Clean column names
    df.columns = df.columns.str.strip()

    # 1. Handling Missing Values
    print("1. Handling Missing Values...")
    num_cols = df.select_dtypes(include=[np.number]).columns
    for col in num_cols:
        df[col].fillna(df[col].median(), inplace=True)
        
    cat_cols = df.select_dtypes(include=['object']).columns
    for col in cat_cols:
        df[col].fillna(df[col].mode()[0], inplace=True)

    # 2. Outlier Treatment (IQR)
    print("2. Treating Outliers...")
    for col in ['income_annum', 'loan_amount', 'residential_assets_value']:
        if col in df.columns:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]

    # 3. Categorical Encoding
    print("3. Feature Encoding & Transformation...")
    label_encoders = {}
    for col in ['education', 'self_employed']:
        if col in df.columns:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col])
            label_encoders[col] = le

    target_le = LabelEncoder()
    df['loan_status'] = target_le.fit_transform(df['loan_status']) # Approved=0/1

    # Drop ID column
    if 'loan_id' in df.columns:
        df.drop(columns=['loan_id'], inplace=True)

    # 4. Feature Selection & Train-Test Split
    feature_cols = [c for c in df.columns if c != 'loan_status']
    X = df[feature_cols]
    y = df['loan_status']

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    # 5. Model Training & Evaluation
    print("5. Training Random Forest Classifier...")
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"Model Accuracy: {acc * 100:.2f}%")
    print(classification_report(y_test, y_pred))

    # Save artifacts into predictor/ml_models/
    os.makedirs('predictor/ml_models', exist_ok=True)
    joblib.dump(model, 'predictor/ml_models/loan_model.pkl')
    joblib.dump(scaler, 'predictor/ml_models/scaler.pkl')
    joblib.dump(feature_cols, 'predictor/ml_models/feature_columns.pkl')
    joblib.dump(label_encoders, 'predictor/ml_models/label_encoders.pkl')
    joblib.dump(target_le, 'predictor/ml_models/target_encoder.pkl')
    print("Artifacts saved successfully in predictor/ml_models/")

if __name__ == '__main__':
    run_pipeline()
